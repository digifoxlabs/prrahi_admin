    <?php if($errors->any()): ?>
    <div class="mb-4 rounded-lg border border-red-200 bg-red-50 p-4 text-red-700">
        <ul class="list-disc list-inside text-sm space-y-1">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
     </div>
    <?php endif; ?>

<div x-data="posOrder()" class="flex flex-col lg:grid lg:grid-cols-12 gap-4">

    <?php
    $isEdit = isset($order);
    ?>

    
    <div class="lg:hidden mb-4">
        <button @click="showProductPopup = true"
                type="button"
                class="w-full px-4 py-3 bg-indigo-600 text-white rounded-lg font-medium">
            📦 Browse Products
        </button>


        
        <?php echo $__env->make('orders.partials.product-popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

    <div class="lg:col-span-12 lg:grid lg:grid-cols-12 gap-4">

        
        <?php echo $__env->make('orders.partials.product-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
        <div class="lg:col-span-8">
            <form method="POST" action="<?php echo e($action); ?>" class="bg-white rounded-xl p-4 border">
                <?php echo csrf_field(); ?>
                <?php if($method === 'PUT'): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

                
                <div class="grid grid-cols-12 gap-3 mb-3">
                    <div class="col-span-12 lg:col-span-6 space-y-3">

                        
                        

                        <!-- Distributor -->
                        <div    x-data
                                x-init="
                                    selectedDistributorId = '<?php echo e(old('distributor_id', $order->distributor_id ?? auth('distributor')->id() ?? '')); ?>';
                                    fillAddress();
                                ">
                            <label class="block font-medium mb-1">Distributor</label>

                            <select name="distributor_id" x-model="selectedDistributorId" @change="fillAddress()"
                                class="w-full border rounded-lg p-2 text-sm" <?php if(auth('distributor')->check()): ?> disabled
                                <?php endif; ?>
                                required>

                                <option value="">Select Distributor</option>

                                <?php $__currentLoopData = $distributors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($d->id); ?>">
                                    <?php echo e($d->firm_name); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            
                            <?php if(auth('distributor')->check()): ?>
                                <input type="hidden"
                                    name="distributor_id"
                                    value="<?php echo e(auth('distributor')->id()); ?>">
                            <?php endif; ?>
                        </div>                        

                        
                        <?php if(auth('distributor')->check()): ?>
                            <input type="hidden" name="distributor_id"
                                   value="<?php echo e(auth('distributor')->id()); ?>">
                        <?php endif; ?>

                        <input type="text"
                               name="order_number"
                               value="<?php echo e(old('order_number', $order->order_number ?? '')); ?>"
                               placeholder="Order Number (optional)"
                               class="w-full border rounded-lg p-2 text-sm">

                        <!-- Order Date -->
                        <div class="relative">
                            <input type="date"
                                name="order_date"
                                value="<?php echo e(old('order_date', isset($order) ? $order->order_date : now()->toDateString())); ?>"
                                class="w-full border rounded-lg p-2 pr-10 text-sm">

                            <button type="button"
                                    onclick="this.previousElementSibling.showPicker && this.previousElementSibling.showPicker()"
                                    class="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500">
                                📅
                            </button>
                        </div>

                    </div>

                    <div class="col-span-12 lg:col-span-6">
                        <textarea name="billing_address"
                                  x-model="billingAddress"
                                  rows="5"
                                  class="w-full h-full border rounded-lg p-2 text-sm resize-none"></textarea>
                    </div>
                </div>

                
                <?php echo $__env->make('orders.partials.pos-table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                
                <?php echo $__env->make('orders.partials.totals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\laravelProjects\prrahi-admin\resources\views/orders/_form.blade.php ENDPATH**/ ?>