

<?php $__env->startSection('page-content'); ?>
<div class="max-w-6xl mx-auto p-4">

    <h2 class="text-xl font-bold mb-4">Sell to Retailer</h2>

    <form method="POST" action="<?php echo e(route('distributor.sales.store')); ?>">
        <?php echo csrf_field(); ?>

        <div class="mb-4">
            <label class="block font-medium mb-1">Retailer</label>
            <select name="retailer_id" class="w-full border p-2 rounded">
                <?php $__currentLoopData = $retailers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($r->id); ?>"><?php echo e($r->retailer_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <table class="w-full text-sm mb-4">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Available</th>
                    <th>Qty</th>
                    <th>Rate</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($stock->product->product_name); ?></td>
                    <td><?php echo e($stock->available_qty); ?></td>

                    <td>
                        <input type="number" name="items[<?php echo e($idx); ?>][qty]" min="0"
                               class="w-20 border p-1">
                        <input type="hidden" name="items[<?php echo e($idx); ?>][product_id]"
                               value="<?php echo e($stock->distributor_product_id); ?>">
                    </td>

                    <td>
                        <input type="number" name="items[<?php echo e($idx); ?>][rate]"
                               value="<?php echo e($stock->product->ptr); ?>"
                               class="w-24 border p-1">
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <button class="bg-green-600 text-white px-4 py-2 rounded">
            Save Sale
        </button>
    </form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('distributor.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelProjects\prrahi-admin\resources\views/distributor/sales/create.blade.php ENDPATH**/ ?>