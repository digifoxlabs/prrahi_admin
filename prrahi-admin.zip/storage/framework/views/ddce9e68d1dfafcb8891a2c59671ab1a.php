<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['distributor', 'action', 'method', 'salesPersons']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['distributor', 'action', 'method', 'salesPersons']); ?>
<?php foreach (array_filter((['distributor', 'action', 'method', 'salesPersons']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<form action="<?php echo e($action); ?>" method="POST" enctype="multipart/form-data"
      class="space-y-10  p-8   text-left transition">
    <?php echo csrf_field(); ?>
    <?php if($method === 'PUT'): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

    
    <?php if($errors->any()): ?>
        <div class="mb-6 p-4 bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-300 border border-red-300 dark:border-red-700 rounded-lg">
            <h3 class="font-semibold mb-2">Please fix the following errors:</h3>
            <ul class="list-disc list-inside space-y-1 text-sm">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    
    <div class="border rounded-xl shadow bg-gray-50 dark:bg-gray-800 p-6 transition">
        <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">🧾 Basic Information</h3>

        <div class="grid grid-cols-2 gap-6">
            
            <div>
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-400 mb-1">Sales Person</label>
                <select name="sales_persons_id"
                        class="w-full border border-gray-300 dark:border-gray-700 rounded-lg px-3 py-2 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-400 focus:ring-blue-500 focus:border-blue-500 transition">
                    <option value="">-- Select Sales Person --</option>
                    <?php $__currentLoopData = $salesPersons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salesPerson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($salesPerson->id); ?>" <?php echo e(old('sales_persons_id', $distributor->sales_persons_id ?? '') == $salesPerson->id ? 'selected' : ''); ?>>
                            <?php echo e($salesPerson->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            
            <div>
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-400 mb-1">Appointment Date *</label>
                <input type="text" id="appointment_date" name="appointment_date"
                       value="<?php echo e(old('appointment_date', isset($distributor) && $distributor->appointment_date ? $distributor->appointment_date->format('Y-m-d') : now()->format('Y-m-d'))); ?>"
                       class="w-full border border-gray-300 dark:border-gray-700 rounded-lg px-3 py-2 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-400 focus:ring-blue-500 focus:border-blue-500 transition">
            </div>

            
            <div>
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-400 mb-1">Firm Name *</label>
                <input type="text" name="firm_name" value="<?php echo e(old('firm_name', $distributor->firm_name ?? '')); ?>"
                       class="w-full border border-gray-300 dark:border-gray-700 rounded-lg px-3 py-2 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-400 focus:ring-blue-500 focus:border-blue-500 transition">
            </div>

            
            <div>
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-400 mb-1">Nature of Firm *</label>
                <select name="nature_of_firm"
                        class="w-full border border-gray-300 dark:border-gray-700 rounded-lg px-3 py-2 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-400 focus:ring-blue-500 focus:border-blue-500 transition">
                    <option value="">-- Select --</option>
                    <?php $__currentLoopData = ['Proprietorship', 'Partnership', 'LLP', 'Pvt Ltd', 'Ltd']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($type); ?>" <?php echo e(old('nature_of_firm', $distributor->nature_of_firm ?? '') == $type ? 'selected' : ''); ?>>
                            <?php echo e($type); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            
            <?php $__currentLoopData = [
                'address_line_1', 'address_line_2', 'town', 'district', 'state', 'pincode', 'landmark',
                'contact_person', 'designation_contact', 'contact_number', 'email', 'gst',
                'date_of_birth', 'date_of_anniversary'
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-400 mb-1">
                        <?php echo e(ucwords(str_replace('_', ' ', $field))); ?>

                    </label>
                    <input type="<?php echo e(in_array($field, ['date_of_birth','date_of_anniversary']) ? 'date' : 'text'); ?>"
                           name="<?php echo e($field); ?>"
                           value="<?php echo e(old($field, $distributor->$field ?? '')); ?>"
                           class="w-full border border-gray-300 dark:border-gray-700 rounded-lg px-3 py-2 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-400 focus:ring-blue-500 focus:border-blue-500 transition">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    
    <div class="border rounded-xl shadow bg-gray-50 dark:bg-gray-800 p-6 transition">
        <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">📍 Location Information</h3>
        <div class="grid grid-cols-2 md:grid-cols-2 gap-6">
            <div>
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-400 mb-1">Latitude</label>
                <input type="text" name="latitude" id="latitude" value="<?php echo e(old('latitude', $distributor->latitude ?? '')); ?>"
                       class="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-400" readonly>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-400 mb-1">Longitude</label>
                <input type="text" name="longitude" id="longitude" value="<?php echo e(old('longitude', $distributor->longitude ?? '')); ?>"
                       class="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-400" readonly>
            </div>
            <div class="md:col-span-2 text-right">
                <button type="button" onclick="openMapModal()"
                        class="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 dark:hover:bg-green-500 transition">
                    📌 Set Location on Map
                </button>
            </div>
        </div>
    </div>

    <?php echo $__env->make('admin.distributors.map-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php
        function getSectionData($key, $distributor) {
            return old($key) ?: ($distributor ? $distributor->{$key}->toArray() : []);
        }
        $dynamicSections = [
            ['title' => 'Distributor Companies', 'key' => 'companies', 'fields' => [
                ['label' => 'Company Name', 'name' => 'company_name'],
                ['label' => 'Segment', 'name' => 'segment'],
                ['label' => 'Brand Name', 'name' => 'brand_name'],
                ['label' => 'Products', 'name' => 'products'],
                ['label' => 'Working As', 'name' => 'working_as'],
                ['label' => 'Margin', 'name' => 'margin'],
                ['label' => 'Payment Terms', 'name' => 'payment_terms'],
                ['label' => 'Working Since', 'name' => 'working_since'],
                ['label' => 'Area of Operation', 'name' => 'area_operation'],
                ['label' => 'Monthly TO', 'name' => 'monthly_to'],
                ['label' => 'DSR No', 'name' => 'dsr_no'],
                ['label' => 'Details', 'name' => 'details'],
            ]],
            ['title' => 'Bank Details', 'key' => 'banks', 'fields' => [
                ['label' => 'Bank Name', 'name' => 'bank_name'],
                ['label' => 'Branch Name', 'name' => 'branch_name'],
                ['label' => 'Current A/C', 'name' => 'current_ac'],
                ['label' => 'IFSC Code', 'name' => 'ifsc'],
            ]],
            ['title' => 'Godown Details', 'key' => 'godowns', 'fields' => [
                ['label' => 'No. of Godowns', 'name' => 'no_godown'],
                ['label' => 'Godown Size', 'name' => 'godown_size'],
            ]],
            ['title' => 'Manpower', 'key' => 'manpowers', 'fields' => [
                ['label' => 'Sales Staff', 'name' => 'sales'],
                ['label' => 'Accounts Staff', 'name' => 'accounts'],
                ['label' => 'Godown Staff', 'name' => 'godown'],
            ]],
            ['title' => 'Vehicles', 'key' => 'vehicles', 'fields' => [
                ['label' => 'Two Wheeler', 'name' => 'two_wheeler'],
                ['label' => 'Three Wheeler', 'name' => 'three_wheeler'],
                ['label' => 'Four Wheeler', 'name' => 'four_wheeler'],
            ]],
        ];
    ?>

    <?php $__currentLoopData = $dynamicSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $sectionData = getSectionData($section['key'], $distributor ?? null); ?>

        <div x-data="{
                items: <?php echo json_encode($sectionData, 15, 512) ?>,
                addItem() { this.items.push({}); },
                removeItem(index) { this.items.splice(index, 1); }
            }"
            class="border rounded-xl bg-gray-50 dark:bg-gray-800 p-6 mb-8 transition">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-semibold text-gray-800 dark:text-white"><?php echo e($section['title']); ?></h3>
                <button type="button" @click="addItem()"
                        class="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700 dark:hover:bg-blue-500 transition">+ Add</button>
            </div>

            <template x-for="(item, index) in items" :key="index">
                <div class="border p-4 mb-4 rounded-lg bg-white dark:bg-gray-900 shadow-sm relative transition">
                    <button type="button" @click="removeItem(index)" class="absolute top-2 right-2 text-red-600 dark:text-red-400 text-xl">&times;</button>
                    <div class="grid grid-cols-2 md:grid-cols-2 gap-4">
                        <?php $__currentLoopData = $section['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <label class="text-sm text-gray-700 dark:text-gray-400"><?php echo e($field['label']); ?></label>
                                <input type="text"
                                       class="w-full px-3 py-2 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-400 focus:ring-blue-500 focus:border-blue-500 transition"
                                       :name="'<?php echo e($section['key']); ?>[' + index + '][<?php echo e($field['name']); ?>]'"
                                       x-model="item['<?php echo e($field['name']); ?>']">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </template>

            <div x-show="items.length === 0" class="text-sm text-gray-500 dark:text-gray-400">
                No <?php echo e(strtolower($section['title'])); ?> added yet.
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <div class="border rounded-xl bg-gray-50 dark:bg-gray-800 p-6 transition">
        <h3 class="text-lg font-semibold text-gray-800 dark:text-white">🔐 Login Credentials</h3>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-400 mb-1">Login ID *</label>
                <input type="text" name="login_id" value="<?php echo e(old('login_id', $distributor->login_id ?? '')); ?>"
                       class="w-full border border-gray-300 dark:border-gray-700 rounded-lg px-3 py-2 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-400 focus:ring-blue-500 focus:border-blue-500 transition">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-400 mb-1">
                    Password <small>
                        <?php if(isset($distributor)): ?>
                            (leave blank if not changing)
                        <?php else: ?>
                            (default: password@123)
                        <?php endif; ?>
                    </small>
                </label>
                <input type="text" name="password"
                       value="<?php echo e(old('password', isset($distributor) ? '' : 'password@123')); ?>"
                       placeholder="<?php echo e(isset($distributor) ? 'Keep blank if not changing' : ''); ?>"
                       class="w-full border border-gray-300 dark:border-gray-700 rounded-lg px-3 py-2 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-400 focus:ring-blue-500 focus:border-blue-500 transition">
            </div>
        </div>
    </div>

    

<div class="flex justify-end gap-4">
    <a href="<?php echo e(route('admin.distributors.index')); ?>"
       class="px-6 py-3 rounded-lg 
              bg-gray-200 text-gray-800 hover:bg-gray-300 
              dark:bg-gray-700 dark:text-gray-400/95 dark:hover:bg-gray-600 dark:hover:text-white
              border border-gray-300 dark:border-gray-600 
              shadow-sm transition
              focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500">
        Cancel
    </a>
    <button type="submit"
            class="px-6 py-3 rounded-lg 
                   bg-blue-600 text-white hover:bg-blue-700 
                   dark:hover:bg-blue-500 
                   shadow-sm transition
                   focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
        Save Distributor
    </button>
</div>



</form>

<script>
    flatpickr("#appointment_date", {
        dateFormat: "Y-m-d",
        defaultDate: "<?php echo e(old('appointment_date', isset($distributor) && $distributor->appointment_date ? $distributor->appointment_date->format('Y-m-d') : now()->format('Y-m-d'))); ?>",
    });
</script>
<?php /**PATH C:\xampp\htdocs\laravelProjects\prrahi-admin\resources\views/admin/distributors/_form.blade.php ENDPATH**/ ?>