<?php if($errors->any()): ?>
    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['p-3', 'bg-red-100', 'text-red-800', 'rounded', 'mb-4']); ?>">
        <strong>There were some errors:</strong>
        <ul class="<?php echo \Illuminate\Support\Arr::toCssClasses(['list-disc', 'pl-5', 'mt-2', 'space-y-1']); ?>">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php
$isEdit = isset($product);
$type = old('type', $product->type ?? 'simple');
$productType = $type;
$selectedCategory = old('category_id', $product->category_id ?? '');
$selectedSubCategory = old('sub_category_id', $product->sub_category_id ?? '');
$variants = [];
$variant = null;

if ($isEdit && $type === 'variant' && $product->parent) {
    $parent = $product->parent;
    $product->name = $parent->name;
    $product->category_id = $parent->category_id;
    $product->sub_category_id = $parent->sub_category_id;
    $product->unit = $parent->unit;
    $selectedCategory = $parent->category_id;
    $selectedSubCategory = $parent->sub_category_id;
    $variant = [
        'id' => $product->id,
        'code' => $product->code,
        'hsn' => $product->hsn,
        'fragrance' => $product->attributes['fragrance'] ?? '',
        'size' => $product->attributes['size'] ?? '',
        'base_unit' => $product->base_unit,
        'base_quantity' => $product->base_quantity,
        'mrp_per_unit' => $product->mrp_per_unit,
        'ptr_per_dozen' => $product->ptr_per_dozen,
        'retailer_discount_percent' => $product->retailer_discount_percent,
        'ptd_per_dozen' => $product->ptd_per_dozen,
        'distributor_discount_percent' => $product->distributor_discount_percent,
        'weight_gm' => $product->weight_gm,
    ];
} elseif ($isEdit && $type === 'variable') {
    $variants = $product->children->map(fn($v) => [
        'id' => $v->id,
        'code' =>$v->code,
        'fragrance' => $v->attributes['fragrance'] ?? '',
        'size' => $v->attributes['size'] ?? '',
        'base_unit' => $v->base_unit,
        'base_quantity' => $v->base_quantity,
        'mrp_per_unit' => $v->mrp_per_unit,
        'ptr_per_dozen' => $v->ptr_per_dozen,
        'retailer_discount_percent' => $v->retailer_discount_percent,
        'ptd_per_dozen' => $v->ptd_per_dozen,
        'distributor_discount_percent' => $v->distributor_discount_percent,
        'weight_gm' => $v->weight_gm,
    ])->toArray();
} else {
    $productType = old('type', 'simple');
    $variants = old('variants', []);
}
?>

<div x-data="productForm()" x-init="init()">
    
    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mb-4']); ?>">
        <label class="<?php echo \Illuminate\Support\Arr::toCssClasses(['font-semibold']); ?>">Product Name</label>
        <?php if($isEdit && $productType === 'variant'): ?>
            <input type="text" name="name" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['w-full', 'border', 'p-2', 'rounded', 'bg-gray-100']); ?>" value="<?php echo e($product->name); ?>" readonly>
        <?php else: ?>
            <input type="text" name="name" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['w-full', 'border', 'p-2', 'rounded']); ?>"
                   value="<?php echo e(old('name', $product->name ?? '')); ?>" required>
        <?php endif; ?>
    </div>

    
    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mb-4']); ?>">
        <?php if(!$isEdit): ?>
            <label class="<?php echo \Illuminate\Support\Arr::toCssClasses(['font-semibold']); ?>">Product Type</label>
            <select name="type" x-model="productType" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['w-full', 'border', 'p-2', 'rounded']); ?>">
                <option value="simple">Simple</option>
                <option value="variable">Variable</option>
            </select>
        <?php else: ?>
            <input type="hidden" name="type" :value="productType">
        <?php endif; ?>
    </div>

    
     <?php if(!$isEdit): ?>
    <div x-show="productType === 'simple'">        
        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mb-4']); ?>">
            <label class="<?php echo \Illuminate\Support\Arr::toCssClasses(['font-semibold']); ?>">Product Code</label>
            <input type="text" name="code" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['w-full', 'border', 'p-2', 'rounded']); ?>"
                value="" placeholder ="Keep Blank for NULL">
        </div>        
        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mb-4']); ?>">
            <label class="<?php echo \Illuminate\Support\Arr::toCssClasses(['font-semibold']); ?>">HSN Code</label>
            <input type="text" name="hsn" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['w-full', 'border', 'p-2', 'rounded']); ?>"
                value="" placeholder ="6 or 8 digit HSN Code">
        </div>        
    </div>
    <?php endif; ?>

    <?php if($isEdit && $productType === 'simple'): ?>
        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mb-4']); ?>">
            <label class="<?php echo \Illuminate\Support\Arr::toCssClasses(['font-semibold']); ?>">Product Code</label>
            <input type="text" name="code" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['w-full', 'border', 'p-2', 'rounded']); ?>"
                value="<?php echo e(old('code', $product->code ?? '')); ?>" placeholder ="Keep Blank for NULL">
        </div>
        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mb-4']); ?>">
            <label class="<?php echo \Illuminate\Support\Arr::toCssClasses(['font-semibold']); ?>">HSN Code</label>
            <input type="text" name="hsn" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['w-full', 'border', 'p-2', 'rounded']); ?>"
                value="<?php echo e(old('hsn', $product->hsn ?? '')); ?>" placeholder ="6 or 8 digit HSN Code">
        </div>
     <?php endif; ?>

    
    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['grid', 'grid-cols-2', 'gap-4', 'mb-4']); ?>">
        <div>
            <label class="<?php echo \Illuminate\Support\Arr::toCssClasses(['font-semibold']); ?>">Segment</label>
            <?php if($isEdit && $productType === 'variant'): ?>
                <input type="text" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['w-full', 'border', 'p-2', 'rounded', 'bg-gray-100']); ?>"
                       value="<?php echo e($product->parent->category->name ?? '-'); ?>" readonly>
            <?php else: ?>
                <select name="category_id" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['w-full', 'border', 'p-2', 'rounded']); ?>"
                        x-model="selectedCategory" @change="fetchSubSegments" required>
                    <option value="">-- Select Segment --</option>
                    <?php $__currentLoopData = $segments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($seg->id); ?>" <?php if($seg->id == $selectedCategory): echo 'selected'; endif; ?>>
                            <?php echo e($seg->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            <?php endif; ?>
        </div>
        <div>
            <label class="<?php echo \Illuminate\Support\Arr::toCssClasses(['font-semibold']); ?>">Sub-Segment</label>
            <?php if($isEdit && $productType === 'variant'): ?>
                <input type="text" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['w-full', 'border', 'p-2', 'rounded', 'bg-gray-100']); ?>"
                       value="<?php echo e($product->parent->subCategory->name ?? '-'); ?>" readonly>
            <?php else: ?>
                <select name="sub_category_id" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['w-full', 'border', 'p-2', 'rounded']); ?>"
                        x-model="selectedSubCategory">
                    <option value="">-- Select Sub-segment --</option>
                    <template x-for="sub in subSegments" :key="sub.id">
                        <option :value="sub.id" x-text="sub.name"
                                :selected="sub.id == selectedSubCategory"></option>
                    </template>
                </select>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['grid', 'grid-cols-2', 'gap-4', 'mb-4']); ?>">
        <div>
            <label class="<?php echo \Illuminate\Support\Arr::toCssClasses(['font-semibold']); ?>">Base Unit</label>
            <?php if($isEdit && $productType === 'variant'): ?>
                <input type="text" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['w-full', 'border', 'p-2', 'rounded', 'bg-gray-100']); ?>"
                    value="<?php echo e(strtoupper($product->parent->base_unit)); ?>" readonly>
            <?php else: ?>
                <select name="base_unit" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['w-full', 'border', 'p-2', 'rounded']); ?>">
                    <option value="">-- Select Unit --</option>
                    <option value="dozen" <?php if(old('base_unit', $product->unit ?? 'dozen') === 'dozen'): echo 'selected'; endif; ?>>Dozen</option>
                    <option value="piece" <?php if(old('base_unit', $product->unit ?? '') === 'piece'): echo 'selected'; endif; ?>>Piece</option>
                    <option value="case" <?php if(old('base_unit', $product->unit ?? '') === 'case'): echo 'selected'; endif; ?>>Case</option>
                </select>
            <?php endif; ?>
        </div>

           <!-- Base Quantity -->
        <div>
            <label class="<?php echo \Illuminate\Support\Arr::toCssClasses(['font-semibold']); ?>">Base Quantity (per unit)</label>
            <?php if($isEdit && $productType === 'variant'): ?>
                <input type="number" step="0.01"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['w-full', 'border', 'p-2', 'rounded', 'bg-gray-100']); ?>"
                    value="<?php echo e($product->parent->base_quantity ?? ''); ?>" readonly>
            <?php else: ?>
                <input type="number" step="0.01" name="base_quantity"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['w-full', 'border', 'p-2', 'rounded']); ?>"
                    value="<?php echo e(old('base_quantity', $product->base_quantity ?? 12)); ?>"
                    placeholder="e.g. 12 for dozen, 1 for piece">
            <?php endif; ?>
            <?php $__errorArgs = ['base_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="<?php echo \Illuminate\Support\Arr::toCssClasses(['text-red-500', 'text-sm', 'mt-1']); ?>"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

    </div>


<?php if($isEdit && $productType === 'variant'): ?>
    <div class="space-y-6 mb-6 bg-white rounded shadow p-6">

        <!-- A) Identity -->
        <div>
            <h4 class="font-semibold mb-3 text-left">Identity</h4>
            <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                <!-- Product Code -->
                <div class="flex flex-col">
                    <label class="text-sm font-medium text-gray-700 mb-1">Product Code</label>
                    <input type="text"
                           name="code"
                           class="border border-gray-300 p-2 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                           placeholder="e.g., PROD-001"
                           value="<?php echo e(old('code', $variant['code'] ?? '')); ?>">
                </div>
                <!-- HSN Code -->
                <div class="flex flex-col">
                    <label class="text-sm font-medium text-gray-700 mb-1">HSN Code</label>
                    <input type="text"
                           name="hsn"
                           class="border border-gray-300 p-2 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                           placeholder="6 or 8 digit hsn code"
                           value="<?php echo e(old('hsn', $variant['hsn'] ?? '')); ?>">
                </div>

                <!-- Fragrance -->
                <div class="flex flex-col">
                    <label class="text-sm font-medium text-gray-700 mb-1">Fragrance</label>
                    <input type="text"
                           name="fragrance"
                           class="border border-gray-300 p-2 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                           placeholder="e.g., Lavender"
                           value="<?php echo e(old('fragrance', $variant['fragrance'] ?? '')); ?>">
                </div>

                <!-- Size -->
                <div class="flex flex-col">
                    <label class="text-sm font-medium text-gray-700 mb-1">Size</label>
                    <input type="text"
                           name="size"
                           class="border border-gray-300 p-2 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                           placeholder="e.g., 250ml"
                           value="<?php echo e(old('size', $variant['size'] ?? '')); ?>">
                </div>
            </div>
        </div>

        <!-- B) Product Specs -->
        <div>
            <h4 class="font-semibold mb-3 text-left">Product Specs</h4>
            <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                <!-- MRP/Unit -->
                <div class="flex flex-col">
                    <label class="text-sm font-medium text-gray-700 mb-1">MRP/Unit</label>
                    <input type="number" step="0.01"
                           name="mrp_per_unit"
                           class="border border-gray-300 p-2 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                           placeholder="e.g., 5.99"
                           value="<?php echo e(old('mrp_per_unit', $variant['mrp_per_unit'] ?? '')); ?>">
                </div>

                <!-- Weight (gm) -->
                <div class="flex flex-col">
                    <label class="text-sm font-medium text-gray-700 mb-1">Weight (gm)</label>
                    <input type="number" step="0.01"
                           name="weight_gm"
                           class="border border-gray-300 p-2 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                           placeholder="e.g., 350.5"
                           value="<?php echo e(old('weight_gm', $variant['weight_gm'] ?? '')); ?>">
                </div>


            </div>
        </div>

        <!-- C) Distributor Pricing -->
        <div>
            <h4 class="font-semibold mb-3 text-left">Distributor Pricing</h4>
            <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                <!-- PTD/Dozen -->
                <div class="flex flex-col">
                    <label class="text-sm font-medium text-gray-700 mb-1">PTD/Dozen</label>
                    <input type="number" step="0.01"
                           name="ptd_per_dozen"
                           class="border border-gray-300 p-2 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                           placeholder="e.g., 54.99"
                           value="<?php echo e(old('ptd_per_dozen', $variant['ptd_per_dozen'] ?? '')); ?>">
                </div>

                <!-- Discount to Distributor (%) -->
                <div class="flex flex-col">
                    <label class="text-sm font-medium text-gray-700 mb-1">Discount to Distributor (%)</label>
                    <input type="number" step="0.01"
                           name="distributor_discount_percent"
                           class="border border-gray-300 p-2 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                           placeholder="e.g., 5"
                           value="<?php echo e(old('distributor_discount_percent', $variant['distributor_discount_percent'] ?? '')); ?>">
                </div>

                <!-- (Optional) Keep a blank column for layout balance or future fields -->
                <div></div>
            </div>
        </div>

        <!-- D) Retailer Pricing -->
        <div>
            <h4 class="font-semibold mb-3 text-left">Retailer Pricing</h4>
            <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                <!-- PTR/Dozen -->
                <div class="flex flex-col">
                    <label class="text-sm font-medium text-gray-700 mb-1">PTR/Dozen</label>
                    <input type="number" step="0.01"
                           name="ptr_per_dozen"
                           class="border border-gray-300 p-2 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                           placeholder="e.g., 59.99"
                           value="<?php echo e(old('ptr_per_dozen', $variant['ptr_per_dozen'] ?? '')); ?>">
                </div>

                <!-- Discount for Retailer (%) -->
                <div class="flex flex-col">
                    <label class="text-sm font-medium text-gray-700 mb-1">Discount for Retailer (%)</label>
                    <input type="number" step="0.01"
                           name="retailer_discount_percent"
                           class="border border-gray-300 p-2 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                           placeholder="e.g., 2.5"
                           value="<?php echo e(old('retailer_discount_percent', $variant['retailer_discount_percent'] ?? '')); ?>">
                </div>

                <!-- (Optional) blank column for alignment -->
                <div></div>
            </div>
        </div>

    </div>
<?php endif; ?>




<template x-if="productType === 'simple'">

    <div class="space-y-6">

    
    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['border', 'rounded-xl', 'p-4', 'md:p-5', 'bg-white']); ?>">
        <h3 class="<?php echo \Illuminate\Support\Arr::toCssClasses(['font-semibold', 'mb-3']); ?>">Product Specs</h3>
        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['grid', 'grid-cols-2', 'md:grid-cols-3', 'gap-4']); ?>">
            
            <div>
                <label class="<?php echo \Illuminate\Support\Arr::toCssClasses(['font-semibold']); ?>">MRP/Unit</label>
                <input type="number" step="0.01" name="mrp_per_unit"
                       class="<?php echo \Illuminate\Support\Arr::toCssClasses(['w-full', 'border', 'p-2', 'rounded']); ?>"
                       value="<?php echo e(old('mrp_per_unit', $product->mrp_per_unit ?? '')); ?>">
                <?php $__errorArgs = ['mrp_per_unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="<?php echo \Illuminate\Support\Arr::toCssClasses(['text-red-500', 'text-sm', 'mt-1']); ?>"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div>
                <label class="<?php echo \Illuminate\Support\Arr::toCssClasses(['font-semibold']); ?>">Weight (gm)</label>
                <input type="number" step="0.01" name="weight_gm"
                       class="<?php echo \Illuminate\Support\Arr::toCssClasses(['w-full', 'border', 'p-2', 'rounded']); ?>"
                       value="<?php echo e(old('weight_gm', $product->weight_gm ?? '')); ?>">
                <?php $__errorArgs = ['weight_gm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="<?php echo \Illuminate\Support\Arr::toCssClasses(['text-red-500', 'text-sm', 'mt-1']); ?>"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div>
                <label class="<?php echo \Illuminate\Support\Arr::toCssClasses(['font-semibold']); ?>">Size</label>
                <input type="text" name="size"
                       class="<?php echo \Illuminate\Support\Arr::toCssClasses(['w-full', 'border', 'p-2', 'rounded']); ?>"
                       value="<?php echo e(old('size', $product->size ?? '')); ?>">
                <?php $__errorArgs = ['size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="<?php echo \Illuminate\Support\Arr::toCssClasses(['text-red-500', 'text-sm', 'mt-1']); ?>"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>

    
    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['border', 'rounded-xl', 'p-4', 'md:p-5', 'bg-white']); ?>">
        <h3 class="<?php echo \Illuminate\Support\Arr::toCssClasses(['font-semibold', 'mb-3']); ?>">Distributor Pricing</h3>
        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['grid', 'grid-cols-2', 'md:grid-cols-3', 'gap-4']); ?>">
            
            <div>
                <label class="<?php echo \Illuminate\Support\Arr::toCssClasses(['font-semibold']); ?>">PTD/Dozen</label>
                <input type="number" step="0.01" name="ptd_per_dozen"
                       class="<?php echo \Illuminate\Support\Arr::toCssClasses(['w-full', 'border', 'p-2', 'rounded']); ?>"
                       value="<?php echo e(old('ptd_per_dozen', $product->ptd_per_dozen ?? '')); ?>">
                <?php $__errorArgs = ['ptd_per_dozen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="<?php echo \Illuminate\Support\Arr::toCssClasses(['text-red-500', 'text-sm', 'mt-1']); ?>"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div>
                <label class="<?php echo \Illuminate\Support\Arr::toCssClasses(['font-semibold']); ?>">Discount to Distributor (%)</label>
                <input type="number" step="0.01" name="distributor_discount_percent"
                       class="<?php echo \Illuminate\Support\Arr::toCssClasses(['w-full', 'border', 'p-2', 'rounded']); ?>"
                       value="<?php echo e(old('distributor_discount_percent', $product->distributor_discount_percent ?? '')); ?>"
                       placeholder="e.g. 5 for 5%">
                <?php $__errorArgs = ['distributor_discount_percent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="<?php echo \Illuminate\Support\Arr::toCssClasses(['text-red-500', 'text-sm', 'mt-1']); ?>"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>

    
    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['border', 'rounded-xl', 'p-4', 'md:p-5', 'bg-white']); ?>">
        <h3 class="<?php echo \Illuminate\Support\Arr::toCssClasses(['font-semibold', 'mb-3']); ?>">Retailer Pricing</h3>
        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['grid', 'grid-cols-2', 'md:grid-cols-3', 'gap-4']); ?>">
            
            <div>
                <label class="<?php echo \Illuminate\Support\Arr::toCssClasses(['font-semibold']); ?>">PTR/Dozen</label>
                <input type="number" step="0.01" name="ptr_per_dozen"
                       class="<?php echo \Illuminate\Support\Arr::toCssClasses(['w-full', 'border', 'p-2', 'rounded']); ?>"
                       value="<?php echo e(old('ptr_per_dozen', $product->ptr_per_dozen ?? '')); ?>">
                <?php $__errorArgs = ['ptr_per_dozen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="<?php echo \Illuminate\Support\Arr::toCssClasses(['text-red-500', 'text-sm', 'mt-1']); ?>"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div>
                <label class="<?php echo \Illuminate\Support\Arr::toCssClasses(['font-semibold']); ?>">Discount for Retailer (%)</label>
                <input type="number" step="0.01" name="retailer_discount_percent"
                       class="<?php echo \Illuminate\Support\Arr::toCssClasses(['w-full', 'border', 'p-2', 'rounded']); ?>"
                       value="<?php echo e(old('retailer_discount_percent', $product->retailer_discount_percent ?? '')); ?>"
                       placeholder="e.g. 2.5 for 2.5%">
                <?php $__errorArgs = ['retailer_discount_percent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="<?php echo \Illuminate\Support\Arr::toCssClasses(['text-red-500', 'text-sm', 'mt-1']); ?>"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>

    </div>
</template>



<div x-show="productType === 'variable'" class="mb-6">
    <label class="font-semibold mb-2 block">Variants</label>

    <template x-for="(variant, index) in variants" :key="index">
        <div class="relative mb-4 p-4 border rounded-xl bg-white shadow-sm space-y-5">

            <!-- Remove button (hidden in edit mode) -->
            <button type="button"
                    class="absolute top-2 right-2 text-red-500 hover:text-red-700 bg-white rounded-full w-6 h-6 flex items-center justify-center shadow-sm"
                    @click="variants.splice(index,1)"
                    x-show="!<?php echo json_encode($isEdit, 15, 512) ?>">✕</button>

            <input type="hidden" :name="'variants['+index+'][id]'" x-model="variant.id">

            <!-- A) Identity -->
            <div>
                <h4 class="font-semibold mb-3">Identity</h4>
                <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <!-- Product Code -->
                    <div class="flex flex-col">
                        <label class="text-sm font-medium text-gray-700 mb-1">Product Code</label>
                        <input type="text"
                               class="border border-gray-300 p-2 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                               :name="'variants['+index+'][code]'"
                               placeholder="e.g., PROD-001"
                               x-model="variant.code">
                    </div>
                    <!-- HSN Code -->
                    <div class="flex flex-col">
                        <label class="text-sm font-medium text-gray-700 mb-1">HSN Code</label>
                        <input type="text"
                               class="border border-gray-300 p-2 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                               :name="'variants['+index+'][hsn]'"
                               placeholder="6 or 8 digit hsn code"
                               x-model="variant.hsn">
                    </div>

                    <!-- Fragrance -->
                    <div class="flex flex-col">
                        <label class="text-sm font-medium text-gray-700 mb-1">Fragrance</label>
                        <input type="text"
                               class="border border-gray-300 p-2 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                               :name="'variants['+index+'][fragrance]'"
                               placeholder="e.g., Lavender"
                               x-model="variant.fragrance">
                    </div>

                    <!-- Size -->
                    <div class="flex flex-col">
                        <label class="text-sm font-medium text-gray-700 mb-1">Size</label>
                        <input type="text"
                               class="border border-gray-300 p-2 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                               :name="'variants['+index+'][size]'"
                               placeholder="e.g., 250ml"
                               x-model="variant.size">
                    </div>
                </div>
            </div>

            <!-- B) Product Specs -->
            <div>
                <h4 class="font-semibold mb-3">Product Specs</h4>
                <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <!-- MRP/Unit -->
                    <div class="flex flex-col">
                        <label class="text-sm font-medium text-gray-700 mb-1">MRP/Unit</label>
                        <input type="number" step="0.01"
                               class="border border-gray-300 p-2 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                               :name="'variants['+index+'][mrp_per_unit]'"
                               placeholder="e.g., 5.99"
                               x-model="variant.mrp_per_unit">
                    </div>

                    <!-- Weight (gm) -->
                    <div class="flex flex-col">
                        <label class="text-sm font-medium text-gray-700 mb-1">Weight (gm)</label>
                        <input type="number" step="0.01"
                               class="border border-gray-300 p-2 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                               :name="'variants['+index+'][weight_gm]'"
                               placeholder="e.g., 350.5"
                               x-model="variant.weight_gm">
                    </div>
                </div>
            </div>

            <!-- C) Distributor Pricing -->
            <div>
                <h4 class="font-semibold mb-3">Distributor Pricing</h4>
                <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <!-- PTD/Dozen -->
                    <div class="flex flex-col">
                        <label class="text-sm font-medium text-gray-700 mb-1">PTD/Dozen</label>
                        <input type="number" step="0.01"
                               class="border border-gray-300 p-2 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                               :name="'variants['+index+'][ptd_per_dozen]'"
                               placeholder="e.g., 54.99"
                               x-model="variant.ptd_per_dozen">
                    </div>

                    <!-- Discount to Distributor (%) -->
                    <div class="flex flex-col">
                        <label class="text-sm font-medium text-gray-700 mb-1">Discount to Distributor (%)</label>
                        <input type="number" step="0.01"
                               class="border border-gray-300 p-2 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                               :name="'variants['+index+'][distributor_discount_percent]'"
                               placeholder="e.g., 5"
                               x-model="variant.distributor_discount_percent">
                    </div>
                </div>
            </div>

            <!-- D) Retailer Pricing -->
            <div>
                <h4 class="font-semibold mb-3">Retailer Pricing</h4>
                <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <!-- PTR/Dozen -->
                    <div class="flex flex-col">
                        <label class="text-sm font-medium text-gray-700 mb-1">PTR/Dozen</label>
                        <input type="number" step="0.01"
                               class="border border-gray-300 p-2 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                               :name="'variants['+index+'][ptr_per_dozen]'"
                               placeholder="e.g., 59.99"
                               x-model="variant.ptr_per_dozen">
                    </div>

                    <!-- Discount for Retailer (%) -->
                    <div class="flex flex-col">
                        <label class="text-sm font-medium text-gray-700 mb-1">Discount for Retailer (%)</label>
                        <input type="number" step="0.01"
                               class="border border-gray-300 p-2 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                               :name="'variants['+index+'][retailer_discount_percent]'"
                               placeholder="e.g., 2.5"
                               x-model="variant.retailer_discount_percent">
                    </div>
                </div>
            </div>


        </div>
    </template>

    <?php if(!$isEdit): ?>
        <button type="button"
                class="mt-2 bg-green-600 text-white px-3 py-1 rounded"
                @click="variants.push({
                    id:'', code:'', fragrance:'', size:'',
                    mrp_per_unit:'', weight_gm:'',
                    ptd_per_dozen:'', distributor_discount_percent:'',
                    ptr_per_dozen:'', retailer_discount_percent:''
                })">
            + Add Variant
        </button>
    <?php endif; ?>
</div>




    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mt-6', 'flex', 'gap-4']); ?>">
        <button class="<?php echo \Illuminate\Support\Arr::toCssClasses(['bg-blue-600', 'text-white', 'px-4', 'py-2', 'rounded']); ?>"><?php echo e($isEdit ? 'Update' : 'Create'); ?></button>
        <a href="<?php echo e(route('admin.products.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['border', 'px-4', 'py-2', 'rounded', 'hover:bg-gray-100']); ?>">Cancel</a>
    </div>
</div>

<script>
function productForm() {
    return {
        productType: <?php echo json_encode($productType, 15, 512) ?>,
        selectedCategory: <?php echo json_encode($selectedCategory, 15, 512) ?>,
        selectedSubCategory: <?php echo json_encode($selectedSubCategory, 15, 512) ?>,
        variants: <?php echo json_encode($variants, 15, 512) ?>,
        subSegments: [],
        async init() { await this.fetchSubSegments(); },
        async fetchSubSegments() {
            if (!this.selectedCategory) { this.subSegments = []; this.selectedSubCategory = ''; return; }
            const res = await fetch('<?php echo e(url('admin/categories')); ?>/' + this.selectedCategory + '/children');
            if (!res.ok) return this.subSegments = [];
            this.subSegments = await res.json();
            if (!this.subSegments.some(s => s.id == this.selectedSubCategory)) {
                this.selectedSubCategory = '';
            }
        }
    }
}
</script>
<?php /**PATH C:\xampp\htdocs\laravelProjects\prrahi-admin\resources\views/admin/products/_form.blade.php ENDPATH**/ ?>