

<?php $__env->startSection('page-content'); ?>
<div class="min-h-screen bg-gray-50 p-4 md:p-6">
    <div class="max-w-5xl mx-auto">

        
        <div class="mb-6">
            <a href="<?php echo e(route('distributor.retailer-sales.index')); ?>"
               class="text-sm text-gray-600 hover:text-gray-900 flex items-center gap-2 mb-3">
                ← Back to Retail Sales
            </a>

            <h1 class="text-2xl font-bold text-gray-900">New Retailer Sale</h1>
            <p class="text-sm text-gray-500">Sell products from your available stock to a retailer</p>
        </div>

        
        <form method="POST"
              action="<?php echo e(route('distributor.retailer-sales.store')); ?>"
              class="bg-white rounded-xl shadow border p-6 space-y-8">
            <?php echo csrf_field(); ?>

            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

                
                <div>
                    <label class="block text-sm font-medium mb-1">Retailer</label>
                    <select name="retailer_id" required
                            class="w-full border rounded-lg p-2">
                        <option value="">-- Select Retailer --</option>
                        <?php $__currentLoopData = $retailers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($r->id); ?>" <?php if(old('retailer_id') == $r->id): echo 'selected'; endif; ?>>
                                <?php echo e($r->retailer_name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['retailer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-xs text-red-600 mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div>
                    <label class="block text-sm font-medium mb-1">Sale Date</label>
                    <input type="date"
                           name="sale_date"
                           value="<?php echo e(old('sale_date', now()->toDateString())); ?>"
                           required
                           class="w-full border rounded-lg p-2">
                </div>
            </div>

            
            <div>
                <div class="flex items-center justify-between mb-3">
                    <h3 class="font-semibold text-gray-800">Products</h3>
                    <button type="button"
                            id="addItem"
                            class="text-sm bg-blue-600 text-white px-3 py-1.5 rounded hover:bg-blue-700">
                        + Add Product
                    </button>
                </div>

                
                <div id="items" class="space-y-3">

                    
                    <div class="item-row grid grid-cols-1 md:grid-cols-3 gap-3 bg-gray-50 p-3 rounded-lg border">
                        
                        <div>
                            <label class="text-sm text-gray-600">Product</label>
                            <select name="items[0][product_id]"
                                    class="w-full border rounded-lg p-2 product-select"
                                    required>
                                <option value="">-- Select Product --</option>
                                <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($stock->product->id); ?>"
                                            data-available="<?php echo e($stock->available_qty); ?>">
                                        <?php echo e($stock->product->product_name); ?>

                                        (Avail: <?php echo e($stock->available_qty); ?>)
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        
                        <div>
                            <label class="text-sm text-gray-600">Quantity</label>
                            <input type="number"
                                   name="items[0][qty]"
                                   min="1"
                                   class="w-full border rounded-lg p-2 qty-input"
                                   required>
                            <p class="text-xs text-red-600 mt-1 hidden qty-error"></p>
                        </div>

                        
                        <div class="flex items-end">
                            <button type="button"
                                    class="remove-item text-red-600 text-sm hidden">
                                Remove
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="flex justify-end gap-3 pt-4 border-t">
                <button type="submit"
                        class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                    Save Sale
                </button>
            </div>
        </form>
    </div>
</div>


<template id="item-template">
    <div class="item-row grid grid-cols-1 md:grid-cols-3 gap-3 bg-gray-50 p-3 rounded-lg border">
        <div>
            <label class="text-sm text-gray-600">Product</label>
            <select class="w-full border rounded-lg p-2 product-select" required></select>
        </div>

        <div>
            <label class="text-sm text-gray-600">Quantity</label>
            <input type="number" min="1"
                   class="w-full border rounded-lg p-2 qty-input" required>
            <p class="text-xs text-red-600 mt-1 hidden qty-error"></p>
        </div>

        <div class="flex items-end">
            <button type="button"
                    class="remove-item text-red-600 text-sm">
                Remove
            </button>
        </div>
    </div>
</template>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>


    window.pageXData = {
        page: 'retailers-sales',
    };
document.addEventListener('DOMContentLoaded', () => {

    let index = 1;
    const items = document.getElementById('items');
    const template = document.getElementById('item-template');
    const form = document.querySelector('form');

    const stockOptions = `
        <option value="">-- Select Product --</option>
        <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($stock->product->id); ?>"
                    data-available="<?php echo e($stock->available_qty); ?>">
                <?php echo e($stock->product->product_name); ?>

                (Avail: <?php echo e($stock->available_qty); ?>)
            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    `;

    function updateDisabledProducts() {
        const selected = [...document.querySelectorAll('.product-select')]
            .map(s => s.value).filter(Boolean);

        document.querySelectorAll('.product-select').forEach(select => {
            [...select.options].forEach(opt => {
                opt.disabled = selected.includes(opt.value) && opt.value !== select.value;
            });
        });
    }

    function attachLogic(row) {
        const select = row.querySelector('.product-select');
        const qty = row.querySelector('.qty-input');
        const error = row.querySelector('.qty-error');

        select.addEventListener('change', () => {
            updateDisabledProducts();
            validate();
        });

        qty.addEventListener('input', validate);

        function validate() {
            const opt = select.selectedOptions[0];
            if (!opt) return;

            const available = parseInt(opt.dataset.available || 0);
            const entered = parseInt(qty.value || 0);

            if (entered > available) {
                error.textContent = `Only ${available} available`;
                error.classList.remove('hidden');
                qty.classList.add('border-red-500');
                form.dataset.invalid = '1';
            } else {
                error.classList.add('hidden');
                qty.classList.remove('border-red-500');
                form.dataset.invalid = '';
            }
        }
    }

    attachLogic(items.querySelector('.item-row'));

    document.getElementById('addItem').addEventListener('click', () => {
        const clone = template.content.cloneNode(true);
        const row = clone.querySelector('.item-row');

        const select = row.querySelector('.product-select');
        const qty = row.querySelector('.qty-input');

        select.name = `items[${index}][product_id]`;
        qty.name = `items[${index}][qty]`;
        select.innerHTML = stockOptions;

        row.querySelector('.remove-item').addEventListener('click', () => {
            row.remove();
            updateDisabledProducts();
        });

        items.appendChild(row);
        attachLogic(row);
        updateDisabledProducts();
        index++;
    });

    form.addEventListener('submit', e => {
        if (form.dataset.invalid === '1') {
            e.preventDefault();
            alert('Please fix quantity errors before submitting.');
        }
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('distributor.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelProjects\prrahi-admin\resources\views/distributor/retailer-sales/create.blade.php ENDPATH**/ ?>