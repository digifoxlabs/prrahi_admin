

<?php $__env->startSection('page-content'); ?>
<div class="max-w-7xl mx-auto bg-white rounded-xl border p-6">

    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
        <h1 class="text-2xl font-bold">Invoices</h1>

        <!-- SEARCH -->
        <form method="GET" class="flex gap-2">
            <input type="text"
                   name="q"
                   value="<?php echo e(request('q')); ?>"
                   placeholder="Search order / invoice / distributor..."
                   class="border rounded-lg px-3 py-2 text-sm w-72">

            <button class="px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm">
                Search
            </button>

            <?php if(request()->filled('q')): ?>
                <a href="<?php echo e(route('admin.invoices.index')); ?>"
                   class="px-3 py-2 border rounded-lg text-sm">
                    Clear
                </a>
            <?php endif; ?>
        </form>
    </div>

    <div class="overflow-x-auto">
        <table class="w-full border text-sm">
            <thead class="bg-gray-100">
                <tr>
                    <th class="p-2 text-left">Invoice No</th>
                    <th class="p-2">Invoice Date</th>
                    <th class="p-2 text-left">Order No</th>
                    <th class="p-2 text-left">Distributor</th>
                    <th class="p-2 text-right">Amount</th>
                    <th class="p-2 text-center">Actions</th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-t hover:bg-gray-50">
                    <td class="p-2 font-medium">
                        <?php echo e($order->invoice_no); ?>

                    </td>

                    <td class="p-2 text-center">
                        <?php echo e(\Carbon\Carbon::parse($order->invoice_date)->format('d M Y')); ?>

                    </td>

                    <td class="p-2">
                        <?php echo e($order->order_number); ?>

                    </td>

                    <td class="p-2">
                        <?php echo e($order->distributor->firm_name); ?>

                    </td>

                    <td class="p-2 text-right font-semibold">
                        <?php echo e(number_format($order->total_amount, 2)); ?>

                    </td>

                    <td class="p-2 text-center">
                        <a href="<?php echo e(route('admin.orders.invoice.print', $order)); ?>"
                           target="_blank"
                           class="inline-flex items-center gap-1 px-3 py-1 bg-indigo-600 text-white rounded-lg text-xs hover:bg-indigo-700">
                            🖨 Print
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="p-4 text-center text-gray-500">
                        No invoices found.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($invoices->links()); ?>

    </div>

</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>

    <script>
        window.pageXData = {
            page: 'invoices',
        };
    </script>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelProjects\prrahi-admin\resources\views/admin/invoices/index.blade.php ENDPATH**/ ?>