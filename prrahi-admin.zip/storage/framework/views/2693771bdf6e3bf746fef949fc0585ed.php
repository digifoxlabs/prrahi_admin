<?php
    $isVariant = $product->parent_id !== null;
    $isVariable = $product->type === 'variable' && $product->parent_id === null;
    $isSimple = $product->type === 'simple';
?>


    

    
        
        <a href="<?php echo e(route('admin.inventory.index')); ?>?product_id=<?php echo e($product->id); ?>"
           class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-blue-600 border-b">
            📦 Inventory
        </a>

        
        <?php if($isSimple || $isVariable): ?>
            <a href="<?php echo e(route('admin.products.edit', $product)); ?>"
               class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-blue-600 border-b">
                ✏️ Edit Product
            </a>
        <?php endif; ?>

         <?php if($isVariable): ?>
            <a href="<?php echo e(route('admin.products.add-variant', $product->id)); ?>"
               class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-blue-600 border-b">
                ✏️ Add Variant
            </a> 

         <?php endif; ?>

        <?php if($isVariant): ?>
            <a href="<?php echo e(route('admin.products.edit', $product)); ?>"
               class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-blue-600 border-b">
                ✏️ Edit Variant
            </a>

            <a href="<?php echo e(route('admin.products.edit', $product->parent_id)); ?>"
               class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-blue-600 border-b">
                ✏️ Edit Parent Product
            </a>

            <a href="<?php echo e(route('admin.products.add-variant', $product->parent_id)); ?>"
               class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-blue-600 border-b">
                ✏️ Add Variant
            </a>          

        <?php endif; ?>

        
        

        
        <form action="<?php echo e(route('admin.products.destroy', $product)); ?>" method="POST"
              onsubmit="return confirm('Are you sure you want to delete this product?')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit"
                    class="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-red-100 hover:text-red-600">
                🗑️ Delete
            </button>
        </form>
    

<?php /**PATH C:\xampp\htdocs\laravelProjects\prrahi-admin\resources\views/admin/products/_actions.blade.php ENDPATH**/ ?>