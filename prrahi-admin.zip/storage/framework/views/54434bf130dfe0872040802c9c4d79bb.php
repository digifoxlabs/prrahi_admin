

<?php $__env->startSection('page-content'); ?>
    <div class="mx-auto max-w-(--breakpoint-2xl) p-4 md:p-6">

      <?php echo $__env->make('admin.orders._breadcrump', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <div
            class="min-h-screen rounded-2xl border border-gray-200 bg-white px-5 py-7 dark:border-gray-800 dark:bg-white/[0.03] xl:px-10 xl:py-12">
            <div class="mx-auto w-full max-w-6xl">



        
            <h2 class="text-xl font-semibold mb-4 dark:text-white">Create New Order</h2>

            <form class="text-center" action="<?php echo e(route('admin.orders.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo $__env->make('admin.orders._form', ['order' => null], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>

           


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        window.pageXData = {
            page: 'createOrder',
        };
    </script>

<?php $__env->stopPush(); ?>




<?php echo $__env->make('admin.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelProjects\prrahi-admin\resources\views/admin/orders/create.blade.php ENDPATH**/ ?>