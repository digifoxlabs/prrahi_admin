<?php if($errors->any()): ?>
    <div class="p-3 bg-red-100 text-red-800 rounded mb-4">
        <strong>There were some errors:</strong>
        <ul class="list-disc pl-5 mt-2 space-y-1">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php
    $isEdit = isset($inventory);
?>

<div class="space-y-4">
    
    <div>
        <label class="font-semibold">Product</label>
<select name="product_id" class="w-full border p-2 rounded" required>
    <option value="">-- Select Product --</option>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $productName = $product->type === 'variant'
                ? ($product->parent->category->name ?? '') . ' - ' . ($product->attributes['fragrance'] ?? '')
                : $product->name;
        ?>
        <option value="<?php echo e($product->id); ?>"
            <?php if(old('product_id', $transaction->product_id ?? '') == $product->id): echo 'selected'; endif; ?>>
            <?php echo e($productName); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
    </div>

    
    <div>
        <label class="font-semibold">Transaction Type</label>
        <select name="type" class="w-full border p-2 rounded" required>
            <option value="">-- Select Type --</option>
            <option value="in" <?php if(old('type', $inventory->type ?? '') === 'in'): echo 'selected'; endif; ?>>In</option>
            <option value="out" <?php if(old('type', $inventory->type ?? '') === 'out'): echo 'selected'; endif; ?>>Out</option>
            <option value="adjustment" <?php if(old('type', $inventory->type ?? '') === 'adjustment'): echo 'selected'; endif; ?>>Adjustment</option>
        </select>
    </div>

    
    <div>
        <label class="font-semibold">Quantity</label>
        <input type="number" name="quantity" class="w-full border p-2 rounded" required
               value="<?php echo e(old('quantity', $inventory->quantity ?? '')); ?>">
    </div>

    
    <div>
        <label class="font-semibold">Date</label>
        <input type="date" name="date" class="w-full border p-2 rounded" required
              value="<?php echo e(old('date', isset($inventory) ? \Illuminate\Support\Carbon::parse($inventory->date)->format('Y-m-d') : now()->format('Y-m-d'))); ?>"
>
    </div>

    
    <div>
        <label class="font-semibold">Remarks</label>
        <textarea name="remarks" required class="w-full border p-2 rounded" rows="3"><?php echo e(old('remarks', $inventory->remarks ?? '')); ?></textarea>
    </div>

    
    <div class="pt-4 flex gap-4">
        <button class="bg-blue-600 text-white px-4 py-2 rounded">
            <?php echo e($isEdit ? 'Update Transaction' : 'Create Transaction'); ?>

        </button>
        <a href="<?php echo e(route('admin.inventory.index')); ?>" class="border px-4 py-2 rounded hover:bg-gray-100">Cancel</a>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\laravelProjects\prrahi-admin\resources\views/admin/inventory/_form.blade.php ENDPATH**/ ?>