<form method="POST" action="<?php echo e($action); ?>" enctype="multipart/form-data" class="space-y-4">
    <?php echo csrf_field(); ?>
    <?php if($method === 'PUT'): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

    
    <?php if($errors->any()): ?>
        <div class="bg-red-100 dark:bg-red-900/40 text-red-800 dark:text-red-300 p-3 rounded mb-4 space-y-1">
            <strong class="block">Please fix the following errors:</strong>
            <ul class="list-disc list-inside text-sm">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="grid grid-cols-2 md:grid-cols-2 gap-4">

        <!-- Retailer Name -->
        <div>
            <label class="font-medium mb-1 block text-gray-700 dark:text-white">Retailer Name *</label>
            <input type="text" name="retailer_name" required
                    placeholder="M/S MAA ENTERPRISE"
                   value="<?php echo e(old('name', $retailer->retailer_name ?? '')); ?>"
                   class="w-full p-2 border rounded border-gray-300 dark:border-gray-700
                          bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-400">
        </div>

        <!-- Contact Person -->
        <div>
            <label class="font-medium mb-1 block text-gray-700 dark:text-white">Contact Person *</label>
            <input type="text" name="contact_person" required
                    placeholder="Full Name"
                   value="<?php echo e(old('contact_person', $retailer->contact_person ?? '')); ?>"
                   class="w-full p-2 border rounded border-gray-300 dark:border-gray-700
                          bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-400">
        </div>

        <!-- Contact Number -->
        <div>
            <label class="font-medium mb-1 block text-gray-700 dark:text-white">Contact Number *</label>
            <input type="numeric" name="contact_number" required
                    placeholder="10 digit mobile number"
                   value="<?php echo e(old('contact_number', $retailer->contact_number ?? '')); ?>"
                   class="w-full p-2 border rounded border-gray-300 dark:border-gray-700
                          bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-400">
        </div>

        <!-- Email -->
        <div>
            <label class="font-medium mb-1 block text-gray-700 dark:text-white">Email</label>
            <input type="email" name="email"
                    placeholder="example@gmail.com"
                   value="<?php echo e(old('email', $retailer->email ?? '')); ?>"
                   class="w-full p-2 border rounded border-gray-300 dark:border-gray-700
                          bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-400">
        </div>

        <!-- GST -->
        <div>
            <label class="font-medium mb-1 block text-gray-700 dark:text-white">GST No (Optional)</label>
            <input type="text" name="gst"
                   value="<?php echo e(old('gst', $retailer->gst ?? '')); ?>"
                   class="w-full p-2 border rounded border-gray-300 dark:border-gray-700
                          bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-400">
        </div>

        <!-- Nature of Outlet -->
        <div>
            <label class="font-medium mb-1 block text-gray-700 dark:text-white">Nature of Outlet</label>
            <input type="text" name="nature_of_outlet"
                   value="<?php echo e(old('nature_of_outlet', $retailer->nature_of_outlet ?? '')); ?>"
                   class="w-full p-2 border rounded border-gray-300 dark:border-gray-700
                          bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-400">
        </div>

        <!-- Address Line 1 -->
        <div>
            <label class="font-medium mb-1 block text-gray-700 dark:text-white">Address Line 1 *</label>
            <input type="text" name="address_line_1"
                    required
                   value="<?php echo e(old('address_line1', $retailer->address_line_1 ?? '')); ?>"
                   class="w-full p-2 border rounded border-gray-300 dark:border-gray-700
                          bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-400">
        </div>

        <!-- Address Line 2 -->
        <div>
            <label class="font-medium mb-1 block text-gray-700 dark:text-white">Address Line 2</label>
            <input type="text" name="address_line_2"
                   value="<?php echo e(old('address_line2', $retailer->address_line_2 ?? '')); ?>"
                   class="w-full p-2 border rounded border-gray-300 dark:border-gray-700
                          bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-400">
        </div>

        <!-- Town -->
        <div>
            <label class="font-medium mb-1 block text-gray-700 dark:text-white">Town</label>
            <input type="text" name="town"
                   value="<?php echo e(old('town', $retailer->town ?? '')); ?>"
                   class="w-full p-2 border rounded border-gray-300 dark:border-gray-700
                          bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-400">
        </div>

        <!-- Landmark -->
        <div>
            <label class="font-medium mb-1 block text-gray-700 dark:text-white">Landmark</label>
            <input type="text" name="landmark"
                   value="<?php echo e(old('town', $retailer->landmark ?? '')); ?>"
                   class="w-full p-2 border rounded border-gray-300 dark:border-gray-700
                          bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-400">
        </div>

        <!-- State -->
        <div>
            <label class="font-medium mb-1 block text-gray-700 dark:text-white">State *</label>
            <select id="state-select" name="state" required
                    class="w-full p-2 border rounded border-gray-300 dark:border-gray-700
                           bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-400">
                <option value="">-- Select State --</option>
                <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($state->name); ?>"
                        <?php if(old('state', $retailer->state ?? '') == $state->name): echo 'selected'; endif; ?>>
                        <?php echo e($state->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- District -->
        <div>
            <label class="font-medium mb-1 block text-gray-700 dark:text-white">District *</label>
            <select id="district-select" name="district" required
                    class="w-full p-2 border rounded border-gray-300 dark:border-gray-700
                        bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-400">
                <?php if(isset($retailer)): ?>
                    <option value="<?php echo e($retailer->district); ?>" selected>
                        <?php echo e($retailer->district); ?>

                    </option>
                <?php else: ?>
                    <option value="">-- Select District --</option>
                <?php endif; ?>
            </select>
        </div>

        <!-- Pincode -->
        <div>
            <label class="font-medium mb-1 block text-gray-700 dark:text-white">Pincode *</label>
            <input type="text" name="pincode"
                   value="<?php echo e(old('pincode', $retailer->pincode ?? '')); ?>"
                   class="w-full p-2 border rounded border-gray-300 dark:border-gray-700
                          bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-400">
        </div>

     
        <!-- Distributor -->
        <div>
            <label class="font-medium mb-1 block text-gray-700 dark:text-white">
                Distributor
            </label>

            <?php if(auth('distributor')->check()): ?>
                
                <input type="hidden"
                    name="distributor_id"
                    value="<?php echo e(auth('distributor')->id()); ?>">

                <input type="text"
                    value="<?php echo e(auth('distributor')->user()->firm_name); ?>"
                    readonly
                    class="w-full p-2 border rounded border-gray-300
                            bg-gray-100 text-gray-700
                            dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 cursor-not-allowed">
            <?php else: ?>
                
                <select name="distributor_id"
                        class="w-full p-2 border rounded border-gray-300 dark:border-gray-700
                            bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-400">
                    <option value="">-- Select Distributor --</option>
                    <?php $__currentLoopData = $distributors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($d->id); ?>"
                            <?php if(old('distributor_id', $retailer->distributor_id ?? '') == $d->id): echo 'selected'; endif; ?>>
                            <?php echo e($d->firm_name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            <?php endif; ?>
        </div>


        
        <!-- Date of Birth -->
        <div>
            <label class="font-medium mb-1 block text-gray-700 dark:text-white">
                Date of Birth
            </label>

            <div class="relative">
                <input type="date"
                    name="date_of_birth"
                    value="<?php echo e(old('date_of_birth', $retailer->date_of_birth ?? '')); ?>"
                    class="w-full border rounded-lg p-2 pr-10 text-sm
                            border-gray-300 dark:border-gray-700
                            bg-white dark:bg-gray-900
                            text-gray-800 dark:text-gray-400">

                <button type="button"
                        onclick="this.previousElementSibling.showPicker && this.previousElementSibling.showPicker()"
                        class="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500">
                    📅
                </button>
            </div>
        </div>


        <!-- Date of Anniversary -->
        <div>
            <label class="font-medium mb-1 block text-gray-700 dark:text-white">
                Date of Anniversary
            </label>

            <div class="relative">
                <input type="date"
                    name="date_of_anniversary"
                    value="<?php echo e(old('date_of_anniversary', $retailer->date_of_anniversary ?? '')); ?>"
                    class="w-full border rounded-lg p-2 pr-10 text-sm
                            border-gray-300 dark:border-gray-700
                            bg-white dark:bg-gray-900
                            text-gray-800 dark:text-gray-400">

                <button type="button"
                        onclick="this.previousElementSibling.showPicker && this.previousElementSibling.showPicker()"
                        class="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500">
                    📅
                </button>
            </div>
        </div>

        

        <div>
            <label class="font-medium mb-1 block text-gray-700 dark:text-white">
                Appointment Date
            </label>

            <div class="relative">
                <input type="date"
                    name="appointment_date"
                    required
                    value="<?php echo e(old(
                        'appointment_date',
                        optional($retailer)->appointment_date
                            ? \Illuminate\Support\Carbon::parse(optional($retailer)->appointment_date)->toDateString()
                            : now()->toDateString()
                    )); ?>"
                    class="w-full border rounded-lg p-2 pr-10 text-sm
                            border-gray-300 dark:border-gray-700
                            bg-white dark:bg-gray-900
                            text-gray-800 dark:text-gray-400">

                <button type="button"
                        onclick="this.previousElementSibling.showPicker && this.previousElementSibling.showPicker()"
                        class="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500">
                    📅
                </button>
            </div>
        </div>





    </div>

    <!-- ACTIONS -->
    <div class="pt-4">
        <button type="submit"
                class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 transition">
            <?php echo e($buttonText); ?>

        </button>

        <a href="<?php echo e(route('distributor.retailers.index')); ?>"
           class="ml-3 px-4 py-2 rounded border border-gray-300 bg-gray-100
                  hover:bg-gray-200 transition">
            Cancel
        </a>
    </div>
</form>



<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/tom-select/dist/js/tom-select.complete.min.js"></script>

<script>


    new TomSelect("#state-select", { create: false, sortField: 'text' });
    const districtSelect = new TomSelect("#district-select", { create: false });

    document.getElementById('state-select').addEventListener('change', function () {
        fetch('<?php echo e(route('distributor.get-districts')); ?>?state=' + this.value)
            .then(res => res.json())
            .then(districts => {
                districtSelect.clearOptions();
                districts.forEach(dist => districtSelect.addOption({ value: dist, text: dist }));
                districtSelect.refreshOptions();
            });
    });

</script>




<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\laravelProjects\prrahi-admin\resources\views/distributor/retailers/_form.blade.php ENDPATH**/ ?>