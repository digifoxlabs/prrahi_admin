<!-- Small Device Overlay Start -->
<div
  @click="sidebarToggle = false"
  :class="sidebarToggle ? 'block lg:hidden' : 'hidden'"
  class="fixed w-full h-screen z-9 bg-gray-900/50"
></div>
<!-- Small Device Overlay End -->