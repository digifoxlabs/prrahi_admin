<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  @vite(['resources/css/app.css', 'resources/js/app.js'])
  </head>
  <body>
    <h1 class="text-base sm:text-2xl md:text-4xl font-bold underline">
      Welcome to Prrahi
    </h1>
  </body>
</html>