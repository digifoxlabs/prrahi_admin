<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Admin\AdminAuthController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\PermissionController;
use App\Http\Controllers\Admin\RoleController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\DistributorController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\FragranceController;
use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\InventoryTransactionController;
use App\Http\Controllers\Admin\SalesPersonController;
use App\Http\Controllers\Admin\AdminOrderController;
use App\Http\Controllers\Admin\SettingsController;
use App\Http\Controllers\Admin\TallyInvoiceController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/alert', function () {
    return view('alert-test');
});

Route::get('/alert-lite', function () {
    return view('alert-test-lite');
});

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('admin/pages/dashboard');
});

Route::get('/login', function () {
    return view('admin/login');
});

Route::get('/sales/login', function () {
    return view('sales/login');
});

Route::get('/distributor/login', function () {
    return view('distributor/login');
});

//Admin Login Routes
Route::prefix('admin')->name('admin.')->group(function(){

    Route::get('/login',[AdminAuthController::class,'showLoginForm'])->name('login');
    Route::post('/login', [AdminAuthController::class, 'login'])->name('login.submit');
      Route::post('/logout', [AdminAuthController::class, 'logout'])->name('logout');

});


//API Instruction Route
Route::get('/api/invoice', function () {
    return view('api/invoice_doc');
});



//Authenticated Admin Routes
Route::prefix('admin')->name('admin.')->middleware('auth:admin')->group(function () {

    //Dashboard
    Route::get('/dashboard', [DashboardController::class, 'dashboard'])->name('dashboard');
    //Profile
     Route::get('/profile', [DashboardController::class, 'profile'])->name('profile');
     //Upload Profile
     Route::post('profile/upload', [DashboardController::class, 'uploadImage'])->name('profile.upload');
     Route::post('profile/remove-image', [DashboardController::class, 'removeImage'])->name('profile.removeImage');
     //Update profile
     Route::post('/profile/update', [DashboardController::class, 'updateProfile'])->name('profile.update');
     Route::post('/profile/update-password', [DashboardController::class, 'updatePassword'])->name('profile.password.update');


     //Permissions
    Route::get('/permissions/export', [PermissionController::class, 'export'])->name('permissions.export');   
    Route::resource('permissions', PermissionController::class)->middleware('permission:view_permissions');

    //Roles
    Route::get('roles/export', [RoleController::class, 'export'])->name('roles.export');
    Route::resource('roles', RoleController::class);

    //Users
    Route::post('/users/profile/upload', [UserController::class, 'uploadImage'])->name('users.profile.upload');
    Route::post('/users/profile/update-password', [UserController::class, 'updatePassword'])->name('users.profile.password.update');
    Route::get('/users/export', [UserController::class, 'export'])->name('users.export');   
    Route::resource('users', UserController::class);
    Route::get('users/{userdata}/assign-roles', [UserController::class, 'assignRoles'])->name('users.assign.roles');
    Route::post('users/{user}/assign-roles', [UserController::class, 'storeRoles'])->name('users.assign.roles.store');

    //Distributor
   Route::post('/distributors/profile/upload/{id}', [DistributorController::class, 'uploadImage'])->name('distributors.updateProfileImage');
   Route::post('/distributors/update-password', [DistributorController::class, 'updatePassword'])->name('distributors.updatePassword');


    // Password update
    Route::get('/distributors/export', [DistributorController::class, 'export'])->name('distributors.export');  
    Route::resource('distributors', DistributorController::class);


    Route::get('/categories/{id}/children', function ($id) {
    return \App\Models\Category::where('parent_id', $id)->get(['id', 'name']);
    })->name('categories.children');

    

    Route::resource('categories', CategoryController::class);

    Route::resource('fragrances', FragranceController::class);


    Route::get('products/{product}/add-variant', [ProductController::class, 'createVariant'])->name('products.add-variant');
    Route::post('products/{product}/store-variant', [ProductController::class, 'storeVariant'])->name('products.store-variant');

    Route::get('/products/export', [ProductController::class, 'export'])->name('products.export');  
    Route::resource('products', ProductController::class);

    Route::get('inventory/export', [InventoryTransactionController::class, 'export'])->name('inventory.export');
    Route::resource('inventory', InventoryTransactionController::class);


    Route::get('get-districts', [SalesPersonController::class, 'getDistricts'])->name('get-districts');


    Route::get('/sales-persons/export', [SalesPersonController::class, 'export'])->name('sales-persons.export');  
    // Profile photo upload
    Route::post('/sales-persons/{salesPerson}/profile/upload', [SalesPersonController::class, 'uploadProfile'])->name('sales-persons.profile.upload');
    // Password update
    Route::post('/sales-persons/update-password', [SalesPersonController::class, 'updatePassword'])->name('sales-persons.updatePassword');
    Route::resource('sales-persons', SalesPersonController::class);


    Route::resource('orders', AdminOrderController::class);
    Route::put('admin/orders/{order}/confirm', [AdminOrderController::class, 'confirm'])->name('orders.confirm');
    Route::put('admin/orders/{order}/cancel', [AdminOrderController::class, 'cancel'])->name('orders.cancel');
   // Route::delete('admin/orders/{order}', [AdminOrderController::class, 'destroy'])->name('admin.orders.destroy');


    Route::get('/settings', [SettingsController::class, 'index'])->name('settings.index');
    Route::post('/settings', [SettingsController::class, 'update'])->name('settings.update');


    Route::get('/invoices', [TallyInvoiceController::class, 'index'])->name('tally.invoices.index');
    Route::get('/invoices/{id}', [TallyInvoiceController::class, 'show'])->name('tally.invoices.show');
    Route::delete('/invoices/{id}', [TallyInvoiceController::class, 'destroy'])->name('tally.invoices.destroy');
    



});
